﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agyiri.Godfred._4H.Levenshtein
{
    class Program
    {
        static void Main(string[] args)
        {
            var  n = 0;
            var m = 0;
            int[,] d = new int[n + 1, m + 1]; // matrice
        }

      public int LD(string s, string t)
      {
          int n = s.Length;
           int m = t.Length;
      }


    }


  
}
